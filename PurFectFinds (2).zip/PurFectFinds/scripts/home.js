// Sample pet data
const featuredPets = [
  {
    id: 1,
    name: "Max",
    breed: "Golden Retriever",
    category: "dogs",
    age: "3 months",
    gender: "Male",
    price: 1200,
    image: "https://www.bing.com/images/search?view=detailV2&ccid=kKBf8FoN&id=4891D2A949FBCD5F2C80241587A7A0E027F98DDB&thid=OIP.kKBf8FoNYCG-9E7hco2DEAHaEo&mediaurl=https%3A%2F%2Fwallpaperaccess.com%2Ffull%2F266770.jpg&exph=1600&expw=2560&q=dogs+images&FORM=IRPRST&ck=25CC73F98475D0DE3D609647B901410C&selectedIndex=6&itb=0&cw=1222&ch=585&ajaxhist=0&ajaxserp=0",
    verified: true,
    vaccinated: true,
    breeder: "Sarah Johnson",
  },
  {
    id: 2,
    name: "Luna",
    breed: "British Shorthair",
    category: "cats",
    age: "2 months",
    gender: "Female",
    price: 800,
    image: "https://images.pexels.com/photos/356378/pexels-photo-356378.jpeg?auto=format%2Ccompress&cs=tinysrgb&dpr=1&w=500",
    verified: true,
    vaccinated: true,
    breeder: "Michael Chen",
  },
  {
    id: 3,
    name: "Charlie",
    breed: "Labrador",
    category: "dogs",
    age: "4 months",
    gender: "Male",
    price: 1000,
    image: "https://th.bing.com/th/id/R.19ef67b1bd7e18add83b179404e80297?rik=MNHM1%2bBRy66Atw&riu=http%3a%2f%2fwallpapercave.com%2fwp%2fGZblMNU.jpg&ehk=7gGoyzI8RuiJXVtgH0FRs2uN%2fwVkdvU8MUTOvSRKmXY%3d&risl=&pid=ImgRaw&r=0",
    verified: true,
    vaccinated: true,
    breeder: "Emily Davis",
  },
  {
    id: 4,
    name: "Bella",
    breed: "Persian Cat",
    category: "cats",
    age: "3 months",
    gender: "Female",
    price: 950,
    image: "https://images.pexels.com/photos/356378/pexels-photo-356378.jpeg?auto=format%2Ccompress&cs=tinysrgb&dpr=1&w=500",
    verified: true,
    vaccinated: true,
    breeder: "David Wilson",
  },
]

// Function to format price
function formatPrice(price) {
  return `₹${price.toLocaleString()}`
}

// Load featured pets
function loadFeaturedPets() {
  const grid = document.getElementById("featuredPetsGrid")
  if (!grid) return

  grid.innerHTML = featuredPets
    .map(
      (pet) => `
        <a href="pet-detail.html?id=${pet.id}" class="pet-card">
            <img src="${pet.image}" alt="${pet.name}" class="pet-image">
            <div class="pet-content">
                <div class="pet-header">
                    <div>
                        <div class="pet-name">${pet.name}</div>
                        <div class="pet-breed">${pet.breed}</div>
                    </div>
                    <div class="pet-price">${formatPrice(pet.price)}</div>
                </div>
                <div class="pet-details">
                    <div class="pet-detail">
                        <span class="pet-detail-label">Age</span>
                        <span class="pet-detail-value">${pet.age}</span>
                    </div>
                    <div class="pet-detail">
                        <span class="pet-detail-label">Gender</span>
                        <span class="pet-detail-value">${pet.gender}</span>
                    </div>
                </div>
                <div class="pet-badges">
                    ${pet.verified ? '<span class="badge badge-success">✓ Verified</span>' : ""}
                    ${pet.vaccinated ? '<span class="badge badge-primary">💉 Vaccinated</span>' : ""}
                </div>
            </div>
        </a>
    `,
    )
    .join("")
}

// Hero search functionality
const heroSearch = document.getElementById("heroSearch")
if (heroSearch) {
  heroSearch.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      const query = heroSearch.value.trim()
      if (query) {
        window.location.href = `pets.html?search=${encodeURIComponent(query)}`
      }
    }
  })

  const searchBtn = document.querySelector(".search-btn")
  if (searchBtn) {
    searchBtn.addEventListener("click", () => {
      const query = heroSearch.value.trim()
      if (query) {
        window.location.href = `pets.html?search=${encodeURIComponent(query)}`
      }
    })
  }
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  loadFeaturedPets()
})
