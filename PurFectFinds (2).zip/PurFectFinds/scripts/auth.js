// Authentication functionality
document.addEventListener("DOMContentLoaded", () => {
  // Check if user is already logged in
  const currentUser = JSON.parse(localStorage.getItem("currentUser"))

  // Redirect to profile if already logged in (except on signup page)
  if (currentUser && !window.location.pathname.includes("signup.html")) {
    if (window.location.pathname.includes("login.html")) {
      window.location.href = "profile.html"
    }
  }

  // Login form
  const loginForm = document.getElementById("loginForm")
  if (loginForm) {
    loginForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const email = document.getElementById("email").value
      const password = document.getElementById("password").value
      const remember = document.getElementById("remember").checked

      // Get users from localStorage
      const users = JSON.parse(localStorage.getItem("users") || "[]")

      // Find user
      const user = users.find((u) => u.email === email && u.password === password)

      if (user) {
        // Store current user
        const userData = {
          id: user.id,
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          userType: user.userType,
          remember: remember,
        }

        localStorage.setItem("currentUser", JSON.stringify(userData))

        // Show success message
        alert("Login successful!")

        // Redirect to profile
        window.location.href = "profile.html"
      } else {
        alert("Invalid email or password. Please try again.")
      }
    })
  }

  // Signup form
  const signupForm = document.getElementById("signupForm")
  if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const firstName = document.getElementById("firstName").value
      const lastName = document.getElementById("lastName").value
      const email = document.getElementById("email").value
      const password = document.getElementById("password").value
      const confirmPassword = document.getElementById("confirmPassword").value
      const userType = document.getElementById("userType").value
      const terms = document.getElementById("terms").checked

      // Validate passwords match
      if (password !== confirmPassword) {
        alert("Passwords do not match!")
        return
      }

      // Validate terms
      if (!terms) {
        alert("Please accept the Terms of Service and Privacy Policy")
        return
      }

      // Get existing users
      const users = JSON.parse(localStorage.getItem("users") || "[]")

      // Check if email already exists
      if (users.some((u) => u.email === email)) {
        alert("An account with this email already exists!")
        return
      }

      // Create new user
      const newUser = {
        id: Date.now().toString(),
        firstName,
        lastName,
        email,
        password,
        userType,
        createdAt: new Date().toISOString(),
      }

      // Add to users array
      users.push(newUser)
      localStorage.setItem("users", JSON.stringify(users))

      // Auto login
      const userData = {
        id: newUser.id,
        email: newUser.email,
        firstName: newUser.firstName,
        lastName: newUser.lastName,
        userType: newUser.userType,
        remember: true,
      }

      localStorage.setItem("currentUser", JSON.stringify(userData))

      // Show success message
      alert("Account created successfully!")

      // Redirect to profile
      window.location.href = "profile.html"
    })
  }

  // Forgot password form
  const forgotPasswordForm = document.getElementById("forgotPasswordForm")
  if (forgotPasswordForm) {
    forgotPasswordForm.addEventListener("submit", (e) => {
      e.preventDefault()

      const email = document.getElementById("email").value

      // In a real app, this would send an email
      alert(`Password reset link has been sent to ${email}`)

      // Redirect to login
      setTimeout(() => {
        window.location.href = "login.html"
      }, 1500)
    })
  }

  // Social auth buttons
  const googleBtn = document.getElementById("googleBtn")
  const githubBtn = document.getElementById("githubBtn")

  if (googleBtn) {
    googleBtn.addEventListener("click", () => {
      alert("Google authentication would be implemented here")
    })
  }

  if (githubBtn) {
    githubBtn.addEventListener("click", () => {
      alert("GitHub authentication would be implemented here")
    })
  }
})
