// Breeder data
const allBreeders = [
  {
    id: 1,
    name: "Sarah Johnson",
    location: "California",
    avatar: "/placeholder.svg?key=bnqxe",
    rating: 4.9,
    reviews: 127,
    pets: 45,
    specialties: ["Golden Retrievers", "Labradors"],
    description: "Experienced breeder specializing in Golden Retrievers and Labradors with over 15 years of expertise.",
    verified: true,
  },
  {
    id: 2,
    name: "Michael Chen",
    location: "New York",
    avatar: "/placeholder.svg?key=bnqxe",
    rating: 4.8,
    reviews: 89,
    pets: 32,
    specialties: ["British Shorthair", "Persian Cats"],
    description: "Certified cat breeder focusing on British Shorthair and Persian breeds with champion bloodlines.",
    verified: true,
  },
  {
    id: 3,
    name: "Emily Davis",
    location: "Texas",
    avatar: "/placeholder.svg?key=bnqxe",
    rating: 4.7,
    reviews: 64,
    pets: 28,
    specialties: ["Poodles", "Beagles"],
    description: "Family-run breeding program dedicated to healthy, well-socialized puppies.",
    verified: true,
  },
  {
    id: 4,
    name: "David Wilson",
    location: "Florida",
    avatar: "/placeholder.svg?key=bnqxe",
    rating: 4.9,
    reviews: 103,
    pets: 38,
    specialties: ["German Shepherds", "Rottweilers"],
    description: "Professional breeder with focus on working dog breeds and temperament testing.",
    verified: true,
  },
]

let filteredBreeders = [...allBreeders]

// Initialize breeders page
function initBreeders() {
  const searchInput = document.getElementById("searchBreeders")
  const sortSelect = document.getElementById("sortBreeders")

  const applyFilters = () => {
    const searchTerm = searchInput.value.toLowerCase()

    filteredBreeders = allBreeders.filter((breeder) => {
      if (
        searchTerm &&
        !breeder.name.toLowerCase().includes(searchTerm) &&
        !breeder.location.toLowerCase().includes(searchTerm)
      ) {
        return false
      }
      return true
    })

    // Apply sorting
    const sortValue = sortSelect.value
    if (sortValue === "rating") {
      filteredBreeders.sort((a, b) => b.rating - a.rating)
    } else if (sortValue === "reviews") {
      filteredBreeders.sort((a, b) => b.reviews - a.reviews)
    } else if (sortValue === "pets") {
      filteredBreeders.sort((a, b) => b.pets - a.pets)
    }

    renderBreeders()
  }

  searchInput.addEventListener("input", applyFilters)
  sortSelect.addEventListener("change", applyFilters)

  applyFilters()
}

// Render breeders
function renderBreeders() {
  const grid = document.getElementById("breedersGrid")

  grid.innerHTML = filteredBreeders
    .map(
      (breeder) => `
        <div class="breeder-card">
            <div class="breeder-header">
                <img src="${breeder.avatar}" alt="${breeder.name}" class="breeder-avatar">
                <div class="breeder-info">
                    <div class="breeder-name">${breeder.name}</div>
                    <div class="breeder-location">📍 ${breeder.location}</div>
                    ${breeder.verified ? '<span class="badge badge-success">✓ Verified</span>' : ""}
                </div>
            </div>
            
            <div class="breeder-specialties">
                ${breeder.specialties.map((s) => `<span class="specialty-tag">${s}</span>`).join("")}
            </div>
            
            <div class="breeder-stats">
                <div class="breeder-stat">
                    <div class="breeder-stat-value">${breeder.rating}</div>
                    <div class="breeder-stat-label">Rating</div>
                </div>
                <div class="breeder-stat">
                    <div class="breeder-stat-value">${breeder.reviews}</div>
                    <div class="breeder-stat-label">Reviews</div>
                </div>
                <div class="breeder-stat">
                    <div class="breeder-stat-value">${breeder.pets}</div>
                    <div class="breeder-stat-label">Pets</div>
                </div>
            </div>
            
            <p class="breeder-description">${breeder.description}</p>
            
            <div class="breeder-actions">
                <a href="breeder-detail.html?name=${encodeURIComponent(breeder.name)}" class="btn-primary">View Profile</a>
                <button class="btn-secondary" onclick="contactBreeder('${breeder.name}')">Contact</button>
            </div>
        </div>
    `,
    )
    .join("")
}

// Contact breeder
function contactBreeder(name) {
  alert(`Message sent to ${name}! They will contact you soon.`)
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  initBreeders()
})
