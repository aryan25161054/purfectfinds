// Pet data (same as pets.js)
const allPets = [
  {
    id: 1,
    name: "Max",
    breed: "Golden Retriever",
    category: "Dogs",
    age: "3 months",
    gender: "Male",
    price: 1200,
    weight: "8 lbs",
    color: "Golden",
    location: "California",
    verified: true,
    vaccinated: true,
    breeder: {
      name: "Sarah Johnson",
      avatar: "/woman-breeder.jpg",
      rating: 4.9,
      reviews: 127,
      pets: 45,
    },
    images: [
      "/golden-retriever-puppy-main.jpg",
      "/golden-retriever-puppy-playing.jpg",
      "/golden-retriever-puppy-sitting.jpg",
      "/golden-retriever-puppy-portrait.jpg",
    ],
    description:
      "Meet Max, an adorable Golden Retriever puppy with a heart of gold! This sweet boy is full of energy and loves to play. He comes from champion bloodlines and has been raised in a loving home environment.",
    healthInfo: [
      "First vaccination completed",
      "Dewormed and flea-free",
      "Vet health certificate included",
      "Microchipped for identification",
      "30-day health guarantee",
    ],
  },
  {
    id: 2,
    name: "Luna",
    breed: "British Shorthair",
    category: "Cats",
    age: "2 months",
    gender: "Female",
    price: 800,
    weight: "3 lbs",
    color: "Blue-Gray",
    location: "New York",
    verified: true,
    vaccinated: true,
    breeder: {
      name: "Michael Chen",
      avatar: "/man-breeder.jpg",
      rating: 4.8,
      reviews: 89,
      pets: 32,
    },
    images: [
      "/british-shorthair-kitten-main.jpg",
      "/british-shorthair-kitten-playing.jpg",
      "/british-shorthair-kitten-sitting.jpg",
      "/british-shorthair-kitten-portrait.jpg",
    ],
    description:
      "Luna is a beautiful British Shorthair kitten with stunning blue-gray fur and captivating copper eyes. She has a calm, gentle temperament and loves cuddles.",
    healthInfo: [
      "First vaccination completed",
      "Dewormed and flea-free",
      "Vet health certificate included",
      "Litter trained",
      "30-day health guarantee",
    ],
  },
]

// Mock formatPrice and auth for demonstration.  In a real application, these would be defined elsewhere.
function formatPrice(price) {
  return "₹" + price.toFixed(2)
}

const auth = {
  isLoggedIn: false, // You would typically check user authentication status here.
}

// Load pet details
function loadPetDetail() {
  const urlParams = new URLSearchParams(window.location.search)
  const petId = Number.parseInt(urlParams.get("id"))
  const pet = allPets.find((p) => p.id === petId)

  if (!pet) {
    document.getElementById("petDetailContent").innerHTML = `
            <div class="no-results">
                <h2>Pet not found</h2>
                <p>The pet you're looking for doesn't exist.</p>
                <a href="pets.html" class="btn-primary">Browse All Pets</a>
            </div>
        `
    return
  }

  const content = document.getElementById("petDetailContent")
  content.innerHTML = `
        <div class="pet-gallery">
            <img src="${pet.images[0]}" alt="${pet.name}" class="main-image" id="mainImage">
            <div class="thumbnail-grid">
                ${pet.images
                  .map(
                    (img, index) => `
                    <img src="${img}" alt="${pet.name}" class="thumbnail ${index === 0 ? "active" : ""}" 
                         onclick="changeMainImage('${img}', this)">
                `,
                  )
                  .join("")}
            </div>
        </div>

        <div class="pet-info">
            <div class="pet-header-info">
                <h1 class="pet-title">${pet.name}</h1>
                <p class="pet-breed-info">${pet.breed} • ${pet.location}</p>
                <div class="pet-price-tag">${formatPrice(pet.price)}</div>
                <div class="pet-badges-detail">
                    ${pet.verified ? '<span class="badge badge-success">✓ Verified Breeder</span>' : ""}
                    ${pet.vaccinated ? '<span class="badge badge-primary">💉 Vaccinated</span>' : ""}
                </div>
                <div class="contact-buttons">
                    <button class="btn-primary btn-large" onclick="contactBreeder()">Contact Breeder</button>
                    <button class="btn-secondary btn-large" onclick="scheduleVisit()">Schedule Visit</button>
                </div>
            </div>

            <div class="pet-details-card">
                <h3 class="details-title">Pet Details</h3>
                <div class="detail-row">
                    <span class="detail-label">Category</span>
                    <span class="detail-value">${pet.category}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Breed</span>
                    <span class="detail-value">${pet.breed}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Age</span>
                    <span class="detail-value">${pet.age}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Gender</span>
                    <span class="detail-value">${pet.gender}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Weight</span>
                    <span class="detail-value">${pet.weight}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Color</span>
                    <span class="detail-value">${pet.color}</span>
                </div>
            </div>

            <div class="breeder-card">
                <h3 class="details-title">Breeder Information</h3>
                <div class="breeder-header">
                    <img src="${pet.breeder.avatar}" alt="${pet.breeder.name}" class="breeder-avatar">
                    <div class="breeder-info">
                        <h3>${pet.breeder.name}</h3>
                        <div class="badge badge-success">✓ Verified</div>
                    </div>
                </div>
                <div class="breeder-stats">
                    <div class="breeder-stat">
                        <div class="breeder-stat-value">${pet.breeder.rating}</div>
                        <div class="breeder-stat-label">Rating</div>
                    </div>
                    <div class="breeder-stat">
                        <div class="breeder-stat-value">${pet.breeder.reviews}</div>
                        <div class="breeder-stat-label">Reviews</div>
                    </div>
                    <div class="breeder-stat">
                        <div class="breeder-stat-value">${pet.breeder.pets}</div>
                        <div class="breeder-stat-label">Pets</div>
                    </div>
                </div>
                <a href="breeder-detail.html?name=${encodeURIComponent(pet.breeder.name)}" class="btn-secondary" style="width: 100%;">View Profile</a>
            </div>
        </div>

        <div class="pet-description">
            <h2>About ${pet.name}</h2>
            <p>${pet.description}</p>
            <h3 style="margin-top: var(--spacing-xl); margin-bottom: var(--spacing-md);">Health Information</h3>
            <ul>
                ${pet.healthInfo.map((info) => `<li>${info}</li>`).join("")}
            </ul>
        </div>
    `
}

// Change main image
function changeMainImage(src, thumbnail) {
  document.getElementById("mainImage").src = src
  document.querySelectorAll(".thumbnail").forEach((t) => t.classList.remove("active"))
  thumbnail.classList.add("active")
}

// Contact breeder
function contactBreeder() {
  if (!auth.isLoggedIn) {
    alert("Please login to contact the breeder")
    window.location.href = "login.html"
    return
  }
  alert("Message sent to breeder! They will contact you soon.")
}

// Schedule visit
function scheduleVisit() {
  if (!auth.isLoggedIn) {
    alert("Please login to schedule a visit")
    window.location.href = "login.html"
    return
  }
  alert("Visit request sent! The breeder will contact you to confirm the date and time.")
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  loadPetDetail()
})
