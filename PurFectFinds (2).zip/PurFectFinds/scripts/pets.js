// Extended pet data
const allPets = [
  {
    id: 1,
    name: "Max",
    breed: "Golden Retriever",
    category: "dogs",
    age: 3,
    ageLabel: "3 months",
    gender: "male",
    price: 1200,
    image: "https://images.pexels.com/photos/356378/pexels-photo-356378.jpeg?auto=format%2Ccompress&cs=tinysrgb&dpr=1&w=500",
    verified: true,
    vaccinated: true,
    breeder: "Sarah Johnson",
    location: "California",
  },
  {
    id: 2,
    name: "Luna",
    breed: "British Shorthair",
    category: "cats",
    age: 2,
    ageLabel: "2 months",
    gender: "female",
    price: 800,
    image: "https://images.pexels.com/photos/356378/pexels-photo-356378.jpeg?auto=format%2Ccompress&cs=tinysrgb&dpr=1&w=500",
    verified: true,
    vaccinated: true,
    breeder: "Michael Chen",
    location: "New York",
  },
  {
    id: 3,
    name: "Charlie",
    breed: "Labrador",
    category: "dogs",
    age: 4,
    ageLabel: "4 months",
    gender: "male",
    price: 1000,
    image: "https://images.pexels.com/photos/356378/pexels-photo-356378.jpeg?auto=format%2Ccompress&cs=tinysrgb&dpr=1&w=500",
    verified: true,
    vaccinated: true,
    breeder: "Emily Davis",
    location: "Texas",
  },
  {
    id: 4,
    name: "Bella",
    breed: "Persian Cat",
    category: "cats",
    age: 3,
    ageLabel: "3 months",
    gender: "female",
    price: 950,
    image: "https://images.pexels.com/photos/356378/pexels-photo-356378.jpeg?auto=format%2Ccompress&cs=tinysrgb&dpr=1&w=500",
    verified: true,
    vaccinated: true,
    breeder: "David Wilson",
    location: "Florida",
  },
  {
    id: 5,
    name: "Rocky",
    breed: "German Shepherd",
    category: "dogs",
    age: 5,
    ageLabel: "5 months",
    gender: "male",
    price: 1500,
    image: "https://images.pexels.com/photos/356378/pexels-photo-356378.jpeg?auto=format%2Ccompress&cs=tinysrgb&dpr=1&w=500",
    verified: true,
    vaccinated: true,
    breeder: "Sarah Johnson",
    location: "California",
  },
  {
    id: 6,
    name: "Daisy",
    breed: "Poodle",
    category: "dogs",
    age: 2,
    ageLabel: "2 months",
    gender: "female",
    price: 1100,
    image: "https://images.pexels.com/photos/356378/pexels-photo-356378.jpeg?auto=format%2Ccompress&cs=tinysrgb&dpr=1&w=500",
    verified: true,
    vaccinated: false,
    breeder: "Michael Chen",
    location: "New York",
  },
  {
    id: 7,
    name: "Milo",
    breed: "Siamese Cat",
    category: "cats",
    age: 4,
    ageLabel: "4 months",
    gender: "male",
    price: 700,
    image: "https://images.pexels.com/photos/356378/pexels-photo-356378.jpeg?auto=format%2Ccompress&cs=tinysrgb&dpr=1&w=500",
    verified: false,
    vaccinated: true,
    breeder: "Emily Davis",
    location: "Texas",
  },
  {
    id: 8,
    name: "Coco",
    breed: "Beagle",
    category: "dogs",
    age: 6,
    ageLabel: "6 months",
    gender: "female",
    price: 900,
    image: "/beagle-puppy.png",
    verified: true,
    vaccinated: true,
    breeder: "David Wilson",
    location: "Florida",
  },
]

let filteredPets = [...allPets]

// Initialize filters
function initFilters() {
  const searchInput = document.getElementById("searchInput")
  const categoryCheckboxes = document.querySelectorAll('input[name="category"]')
  const ageCheckboxes = document.querySelectorAll('input[name="age"]')
  const genderCheckboxes = document.querySelectorAll('input[name="gender"]')
  const minPrice = document.getElementById("minPrice")
  const maxPrice = document.getElementById("maxPrice")
  const verifiedOnly = document.getElementById("verifiedOnly")
  const vaccinatedOnly = document.getElementById("vaccinatedOnly")
  const sortBy = document.getElementById("sortBy")
  const clearFilters = document.getElementById("clearFilters")

  // Apply filters on any change
  const applyFilters = () => {
    filteredPets = allPets.filter((pet) => {
      // Search filter
      const searchTerm = searchInput.value.toLowerCase()
      if (searchTerm && !pet.name.toLowerCase().includes(searchTerm) && !pet.breed.toLowerCase().includes(searchTerm)) {
        return false
      }

      // Category filter
      const selectedCategories = Array.from(categoryCheckboxes)
        .filter((cb) => cb.checked)
        .map((cb) => cb.value)
      if (selectedCategories.length > 0 && !selectedCategories.includes(pet.category)) {
        return false
      }

      // Age filter
      const selectedAges = Array.from(ageCheckboxes)
        .filter((cb) => cb.checked)
        .map((cb) => cb.value)
      if (selectedAges.length > 0) {
        const petAge = pet.age
        const matchesAge = selectedAges.some((range) => {
          if (range === "0-3") return petAge >= 0 && petAge <= 3
          if (range === "3-6") return petAge > 3 && petAge <= 6
          if (range === "6-12") return petAge > 6 && petAge <= 12
          if (range === "12+") return petAge > 12
          return false
        })
        if (!matchesAge) return false
      }

      // Gender filter
      const selectedGenders = Array.from(genderCheckboxes)
        .filter((cb) => cb.checked)
        .map((cb) => cb.value)
      if (selectedGenders.length > 0 && !selectedGenders.includes(pet.gender)) {
        return false
      }

      // Price filter
      const min = minPrice.value ? Number.parseInt(minPrice.value) : 0
      const max = maxPrice.value ? Number.parseInt(maxPrice.value) : Number.POSITIVE_INFINITY
      if (pet.price < min || pet.price > max) {
        return false
      }

      // Verification filters
      if (verifiedOnly.checked && !pet.verified) return false
      if (vaccinatedOnly.checked && !pet.vaccinated) return false

      return true
    })

    // Apply sorting
    const sortValue = sortBy.value
    if (sortValue === "price-low") {
      filteredPets.sort((a, b) => a.price - b.price)
    } else if (sortValue === "price-high") {
      filteredPets.sort((a, b) => b.price - a.price)
    } else if (sortValue === "age") {
      filteredPets.sort((a, b) => a.age - b.age)
    } else {
      filteredPets.sort((a, b) => b.id - a.id)
    }

    renderPets()
  }

  // Event listeners
  searchInput.addEventListener("input", applyFilters)
  categoryCheckboxes.forEach((cb) => cb.addEventListener("change", applyFilters))
  ageCheckboxes.forEach((cb) => cb.addEventListener("change", applyFilters))
  genderCheckboxes.forEach((cb) => cb.addEventListener("change", applyFilters))
  minPrice.addEventListener("input", applyFilters)
  maxPrice.addEventListener("input", applyFilters)
  verifiedOnly.addEventListener("change", applyFilters)
  vaccinatedOnly.addEventListener("change", applyFilters)
  sortBy.addEventListener("change", applyFilters)

  // Clear filters
  clearFilters.addEventListener("click", () => {
    searchInput.value = ""
    categoryCheckboxes.forEach((cb) => (cb.checked = false))
    ageCheckboxes.forEach((cb) => (cb.checked = false))
    genderCheckboxes.forEach((cb) => (cb.checked = false))
    minPrice.value = ""
    maxPrice.value = ""
    verifiedOnly.checked = false
    vaccinatedOnly.checked = false
    sortBy.value = "newest"
    applyFilters()
  })

  // Check URL parameters
  const urlParams = new URLSearchParams(window.location.search)
  const category = urlParams.get("category")
  const search = urlParams.get("search")

  if (category) {
    const checkbox = document.querySelector(`input[name="category"][value="${category}"]`)
    if (checkbox) checkbox.checked = true
  }

  if (search) {
    searchInput.value = search
  }

  applyFilters()
}

function formatPrice(price) {
  return `₹${price.toFixed(2)}`
}

// Render pets
function renderPets() {
  const grid = document.getElementById("petsGrid")
  const resultsCount = document.getElementById("resultsCount")
  const noResults = document.getElementById("noResults")

  resultsCount.textContent = `Showing ${filteredPets.length} pet${filteredPets.length !== 1 ? "s" : ""}`

  if (filteredPets.length === 0) {
    grid.style.display = "none"
    noResults.style.display = "block"
    return
  }

  grid.style.display = "grid"
  noResults.style.display = "none"

  grid.innerHTML = filteredPets
    .map(
      (pet) => `
        <a href="pet-detail.html?id=${pet.id}" class="pet-card">
            <img src="${pet.image}" alt="${pet.name}" class="pet-image">
            <div class="pet-content">
                <div class="pet-header">
                    <div>
                        <div class="pet-name">${pet.name}</div>
                        <div class="pet-breed">${pet.breed}</div>
                    </div>
                    <div class="pet-price">${formatPrice(pet.price)}</div>
                </div>
                <div class="pet-details">
                    <div class="pet-detail">
                        <span class="pet-detail-label">Age</span>
                        <span class="pet-detail-value">${pet.ageLabel}</span>
                    </div>
                    <div class="pet-detail">
                        <span class="pet-detail-label">Gender</span>
                        <span class="pet-detail-value">${pet.gender.charAt(0).toUpperCase() + pet.gender.slice(1)}</span>
                    </div>
                </div>
                <div class="pet-badges">
                    ${pet.verified ? '<span class="badge badge-success">✓ Verified</span>' : ""}
                    ${pet.vaccinated ? '<span class="badge badge-primary">💉 Vaccinated</span>' : ""}
                </div>
            </div>
        </a>
    `,
    )
    .join("")
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  initFilters()
})
