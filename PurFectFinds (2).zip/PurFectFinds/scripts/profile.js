// Profile page functionality
document.addEventListener("DOMContentLoaded", () => {
  // Check if user is logged in
  const currentUser = JSON.parse(localStorage.getItem("currentUser"))

  if (!currentUser) {
    window.location.href = "login.html"
    return
  }

  // Get full user data
  const users = JSON.parse(localStorage.getItem("users") || "[]")
  const user = users.find((u) => u.id === currentUser.id)

  // Populate profile form
  if (user) {
    document.getElementById("firstName").value = user.firstName || ""
    document.getElementById("lastName").value = user.lastName || ""
    document.getElementById("email").value = user.email || ""
    document.getElementById("phone").value = user.phone || ""
    document.getElementById("address").value = user.address || ""
  }

  // Tab navigation
  const tabLinks = document.querySelectorAll(".profile-nav a")
  const tabContents = document.querySelectorAll(".tab-content")

  tabLinks.forEach((link) => {
    link.addEventListener("click", function (e) {
      e.preventDefault()

      const tabName = this.getAttribute("data-tab")

      // Remove active class from all tabs
      tabLinks.forEach((l) => l.classList.remove("active"))
      tabContents.forEach((c) => c.classList.remove("active"))

      // Add active class to clicked tab
      this.classList.add("active")
      document.getElementById(tabName).classList.add("active")
    })
  })

  // Edit profile
  const editProfileBtn = document.getElementById("editProfileBtn")
  const cancelEditBtn = document.getElementById("cancelEditBtn")
  const profileForm = document.getElementById("profileForm")
  const formActions = document.getElementById("formActions")
  const formInputs = profileForm.querySelectorAll("input, textarea")

  editProfileBtn.addEventListener("click", () => {
    formInputs.forEach((input) => {
      if (input.id !== "email") {
        // Don't allow email editing
        input.disabled = false
      }
    })
    formActions.style.display = "flex"
    editProfileBtn.style.display = "none"
  })

  cancelEditBtn.addEventListener("click", () => {
    formInputs.forEach((input) => (input.disabled = true))
    formActions.style.display = "none"
    editProfileBtn.style.display = "block"

    // Reset form values
    if (user) {
      document.getElementById("firstName").value = user.firstName || ""
      document.getElementById("lastName").value = user.lastName || ""
      document.getElementById("phone").value = user.phone || ""
      document.getElementById("address").value = user.address || ""
    }
  })

  profileForm.addEventListener("submit", (e) => {
    e.preventDefault()

    // Update user data
    const updatedUser = {
      ...user,
      firstName: document.getElementById("firstName").value,
      lastName: document.getElementById("lastName").value,
      phone: document.getElementById("phone").value,
      address: document.getElementById("address").value,
    }

    // Update in users array
    const userIndex = users.findIndex((u) => u.id === currentUser.id)
    users[userIndex] = updatedUser
    localStorage.setItem("users", JSON.stringify(users))

    // Update current user
    currentUser.firstName = updatedUser.firstName
    currentUser.lastName = updatedUser.lastName
    localStorage.setItem("currentUser", JSON.stringify(currentUser))

    // Disable inputs and hide actions
    formInputs.forEach((input) => (input.disabled = true))
    formActions.style.display = "none"
    editProfileBtn.style.display = "block"

    alert("Profile updated successfully!")
  })

  // User menu dropdown
  const userMenuBtn = document.getElementById("userMenuBtn")
  const userDropdown = document.getElementById("userDropdown")

  if (userMenuBtn && userDropdown) {
    userMenuBtn.addEventListener("click", (e) => {
      e.stopPropagation()
      userDropdown.classList.toggle("active")
    })

    document.addEventListener("click", () => {
      userDropdown.classList.remove("active")
    })
  }

  // Logout functionality
  const logoutBtn = document.getElementById("logoutBtn")
  const mobileLogoutBtn = document.getElementById("mobileLogoutBtn")

  function handleLogout(e) {
    e.preventDefault()

    if (confirm("Are you sure you want to logout?")) {
      localStorage.removeItem("currentUser")
      window.location.href = "index.html"
    }
  }

  if (logoutBtn) {
    logoutBtn.addEventListener("click", handleLogout)
  }

  if (mobileLogoutBtn) {
    mobileLogoutBtn.addEventListener("click", handleLogout)
  }
})
