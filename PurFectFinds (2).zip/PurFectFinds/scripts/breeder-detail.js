// Breeder data with full details
const breederData = {
  "Sarah Johnson": {
    name: "Sarah Johnson",
    location: "Los Angeles, California",
    avatar: "/placeholder.svg?key=bnqxe",
    rating: 4.9,
    reviews: 127,
    pets: 45,
    yearsExperience: 15,
    specialties: ["Golden Retrievers", "Labradors"],
    about:
      "With over 15 years of experience, I specialize in breeding Golden Retrievers and Labradors with champion bloodlines. My breeding program focuses on health, temperament, and conformation to breed standards. All my puppies are raised in a family environment and receive early socialization.",
    certifications: [
      { icon: "✓", text: "AKC Certified Breeder" },
      { icon: "🏆", text: "Champion Bloodlines" },
      { icon: "🏥", text: "Health Tested" },
      { icon: "📜", text: "Licensed & Insured" },
    ],
    availablePets: [
      {
        id: 1,
        name: "Max",
        breed: "Golden Retriever",
        age: "3 months",
        price: 1200,
        image: "/placeholder.svg?key=rtyo4",
      },
      {
        id: 5,
        name: "Rocky",
        breed: "German Shepherd",
        age: "5 months",
        price: 1500,
        image: "/placeholder.svg?key=h7zwk",
      },
    ],
    reviews: [
      {
        author: "John Smith",
        date: "January 15, 2025",
        rating: 5,
        text: "Sarah is an amazing breeder! Our Golden Retriever puppy is healthy, well-socialized, and has the best temperament. Highly recommend!",
      },
      {
        author: "Lisa Brown",
        date: "December 28, 2024",
        rating: 5,
        text: "Professional and caring. Sarah provided excellent support even after we brought our puppy home. The health guarantee gave us peace of mind.",
      },
      {
        author: "Mike Johnson",
        date: "November 10, 2024",
        rating: 5,
        text: "Best breeder experience ever! The facility was clean, the dogs were happy and healthy. Our Labrador is perfect!",
      },
    ],
  },
  "Michael Chen": {
    name: "Michael Chen",
    location: "Brooklyn, New York",
    avatar: "/placeholder.svg?key=bnqxe",
    rating: 4.8,
    reviews: 89,
    pets: 32,
    yearsExperience: 12,
    specialties: ["British Shorthair", "Persian Cats"],
    about:
      "I am a certified cat breeder with 12 years of experience specializing in British Shorthair and Persian breeds. My cattery is registered and all my cats come from champion bloodlines with excellent health records.",
    certifications: [
      { icon: "✓", text: "CFA Registered" },
      { icon: "🏆", text: "Champion Bloodlines" },
      { icon: "🏥", text: "Health Tested" },
      { icon: "📜", text: "Licensed Cattery" },
    ],
    availablePets: [
      {
        id: 2,
        name: "Luna",
        breed: "British Shorthair",
        age: "2 months",
        price: 800,
        image: "/placeholder.svg?key=l4foo",
      },
    ],
    reviews: [
      {
        author: "Emma Wilson",
        date: "January 20, 2025",
        rating: 5,
        text: "Our British Shorthair kitten is absolutely perfect! Michael was very knowledgeable and helpful throughout the process.",
      },
      {
        author: "David Lee",
        date: "December 15, 2024",
        rating: 5,
        text: "Excellent breeder with beautiful cats. The kitten came with all health records and was well-socialized.",
      },
    ],
  },
}

function formatPrice(price) {
  return "$" + price.toFixed(2)
}

// Load breeder detail
function loadBreederDetail() {
  const urlParams = new URLSearchParams(window.location.search)
  const breederName = urlParams.get("name")
  const breeder = breederData[breederName]

  if (!breeder) {
    document.getElementById("breederDetailContent").innerHTML = `
            <div class="no-results">
                <h2>Breeder not found</h2>
                <p>The breeder you're looking for doesn't exist.</p>
                <a href="breeders.html" class="btn-primary">Browse All Breeders</a>
            </div>
        `
    return
  }

  const content = document.getElementById("breederDetailContent")
  content.innerHTML = `
        <div class="breeder-profile-header">
            <div class="breeder-profile-top">
                <img src="${breeder.avatar}" alt="${breeder.name}" class="breeder-profile-avatar">
                <div class="breeder-profile-info">
                    <h1 class="breeder-profile-name">${breeder.name}</h1>
                    <p class="breeder-profile-location">📍 ${breeder.location}</p>
                    <div class="breeder-profile-badges">
                        <span class="badge badge-success">✓ Verified Breeder</span>
                        ${breeder.specialties.map((s) => `<span class="specialty-tag">${s}</span>`).join("")}
                    </div>
                    <div class="breeder-profile-actions">
                        <button class="btn-primary" onclick="contactBreeder()">Contact Breeder</button>
                        <button class="btn-secondary" onclick="scheduleVisit()">Schedule Visit</button>
                    </div>
                </div>
            </div>
            
            <div class="breeder-profile-stats">
                <div class="profile-stat">
                    <div class="profile-stat-value">${breeder.rating}</div>
                    <div class="profile-stat-label">Rating</div>
                </div>
                <div class="profile-stat">
                    <div class="profile-stat-value">${breeder.reviews}</div>
                    <div class="profile-stat-label">Reviews</div>
                </div>
                <div class="profile-stat">
                    <div class="profile-stat-value">${breeder.pets}</div>
                    <div class="profile-stat-label">Pets Available</div>
                </div>
                <div class="profile-stat">
                    <div class="profile-stat-value">${breeder.yearsExperience}</div>
                    <div class="profile-stat-label">Years Experience</div>
                </div>
            </div>
        </div>

        <div class="breeder-about">
            <h2>About ${breeder.name}</h2>
            <p>${breeder.about}</p>
            
            <h3 style="margin-top: var(--spacing-xl); margin-bottom: var(--spacing-lg);">Certifications & Credentials</h3>
            <div class="certifications">
                ${breeder.certifications
                  .map(
                    (cert) => `
                    <div class="certification-badge">
                        <span class="certification-icon">${cert.icon}</span>
                        <span class="certification-text">${cert.text}</span>
                    </div>
                `,
                  )
                  .join("")}
            </div>
        </div>

        <div class="breeder-pets">
            <h2>Available Pets</h2>
            <div class="pet-grid">
                ${breeder.availablePets
                  .map(
                    (pet) => `
                    <a href="pet-detail.html?id=${pet.id}" class="pet-card">
                        <img src="${pet.image}" alt="${pet.name}" class="pet-image">
                        <div class="pet-content">
                            <div class="pet-header">
                                <div>
                                    <div class="pet-name">${pet.name}</div>
                                    <div class="pet-breed">${pet.breed}</div>
                                </div>
                                <div class="pet-price">${formatPrice(pet.price)}</div>
                            </div>
                            <div class="pet-details">
                                <div class="pet-detail">
                                    <span class="pet-detail-label">Age</span>
                                    <span class="pet-detail-value">${pet.age}</span>
                                </div>
                            </div>
                        </div>
                    </a>
                `,
                  )
                  .join("")}
            </div>
        </div>

        <div class="breeder-reviews">
            <h2>Reviews (${breeder.reviews.length})</h2>
            ${breeder.reviews
              .map(
                (review) => `
                <div class="review-card">
                    <div class="review-header">
                        <div>
                            <div class="review-author">${review.author}</div>
                            <div class="review-date">${review.date}</div>
                        </div>
                        <div class="review-rating">
                            ${"★".repeat(review.rating)}
                        </div>
                    </div>
                    <p class="review-text">${review.text}</p>
                </div>
            `,
              )
              .join("")}
        </div>
    `
}

// Contact breeder
function contactBreeder() {
  alert("Message sent to breeder! They will contact you soon.")
}

// Schedule visit
function scheduleVisit() {
  alert("Visit request sent! The breeder will contact you to confirm the date and time.")
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  loadBreederDetail()
})
