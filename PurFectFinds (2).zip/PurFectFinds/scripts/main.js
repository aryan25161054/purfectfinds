// Mobile Menu Toggle
const mobileMenuBtn = document.getElementById("mobileMenuBtn")
const mobileMenu = document.getElementById("mobileMenu")

if (mobileMenuBtn) {
  mobileMenuBtn.addEventListener("click", () => {
    mobileMenu.classList.toggle("active")
  })
}

// Close mobile menu when clicking outside
document.addEventListener("click", (e) => {
  if (mobileMenu && mobileMenu.classList.contains("active")) {
    if (!mobileMenu.contains(e.target) && !mobileMenuBtn.contains(e.target)) {
      mobileMenu.classList.remove("active")
    }
  }
})

// Authentication State Management
const auth = {
  isLoggedIn: false,
  user: null,

  init() {
    const userData = localStorage.getItem("user")
    if (userData) {
      this.user = JSON.parse(userData)
      this.isLoggedIn = true
      this.updateUI()
    }
  },

  login(email, password) {
    // Simulate login - in production, this would call an API
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    const user = users.find((u) => u.email === email && u.password === password)

    if (user) {
      this.user = { email: user.email, name: user.name }
      this.isLoggedIn = true
      localStorage.setItem("user", JSON.stringify(this.user))
      this.updateUI()
      return true
    }
    return false
  },

  signup(name, email, password) {
    // Simulate signup - in production, this would call an API
    const users = JSON.parse(localStorage.getItem("users") || "[]")

    if (users.find((u) => u.email === email)) {
      return { success: false, message: "Email already exists" }
    }

    const newUser = { name, email, password }
    users.push(newUser)
    localStorage.setItem("users", JSON.stringify(users))

    this.user = { email, name }
    this.isLoggedIn = true
    localStorage.setItem("user", JSON.stringify(this.user))
    this.updateUI()

    return { success: true }
  },

  logout() {
    this.user = null
    this.isLoggedIn = false
    localStorage.removeItem("user")
    this.updateUI()
    window.location.href = "index.html"
  },

  updateUI() {
    const navActions = document.querySelector(".nav-actions")
    if (navActions && this.isLoggedIn) {
      navActions.innerHTML = `
                <span style="color: var(--text-secondary); margin-right: 1rem;">Hello, ${this.user.name}</span>
                <a href="profile.html" class="btn-secondary">Profile</a>
                <button onclick="auth.logout()" class="btn-primary">Logout</button>
            `
    }
  },
}

// Initialize auth on page load
document.addEventListener("DOMContentLoaded", () => {
  auth.init()
})

// Utility Functions
function formatPrice(price) {
  return `$${price.toLocaleString()}`
}

function getQueryParam(param) {
  const urlParams = new URLSearchParams(window.location.search)
  return urlParams.get(param)
}

function setQueryParam(param, value) {
  const url = new URL(window.location)
  url.searchParams.set(param, value)
  window.history.pushState({}, "", url)
}
