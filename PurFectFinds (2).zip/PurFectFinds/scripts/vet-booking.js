// Vet data (same as vet.js)
const allVets = [
  {
    id: 1,
    name: "Dr. Emily Parker",
    specialty: "General Practice",
    avatar: "/placeholder.svg?key=vet1",
    rating: 4.9,
    reviews: 156,
    experience: "12 years",
    availability: "Mon-Fri, 9AM-5PM",
  },
  {
    id: 2,
    name: "Dr. James Wilson",
    specialty: "Surgery",
    avatar: "/placeholder.svg?key=vet2",
    rating: 4.8,
    reviews: 98,
    experience: "15 years",
    availability: "Tue-Sat, 10AM-6PM",
  },
  {
    id: 3,
    name: "Dr. Sarah Chen",
    specialty: "Dental Care",
    avatar: "/placeholder.svg?key=vet3",
    rating: 4.9,
    reviews: 134,
    experience: "10 years",
    availability: "Mon-Thu, 8AM-4PM",
  },
  {
    id: 4,
    name: "Dr. Michael Brown",
    specialty: "Emergency Care",
    avatar: "/placeholder.svg?key=vet4",
    rating: 4.7,
    reviews: 203,
    experience: "18 years",
    availability: "24/7 Emergency",
  },
]

// Load vet info
function loadVetInfo() {
  const urlParams = new URLSearchParams(window.location.search)
  const vetId = Number.parseInt(urlParams.get("id"))
  const vet = allVets.find((v) => v.id === vetId)

  if (!vet) {
    document.getElementById("vetInfoSidebar").innerHTML = `
            <div class="no-results">
                <p>Veterinarian not found</p>
            </div>
        `
    return
  }

  const sidebar = document.getElementById("vetInfoSidebar")
  sidebar.innerHTML = `
        <div class="vet-sidebar-header">
            <img src="${vet.avatar}" alt="${vet.name}" class="vet-sidebar-avatar">
            <div class="vet-sidebar-name">${vet.name}</div>
            <div class="vet-sidebar-specialty">${vet.specialty}</div>
            <div class="vet-rating">
                <span class="vet-stars">${"★".repeat(Math.floor(vet.rating))}${"☆".repeat(5 - Math.floor(vet.rating))}</span>
                <span class="vet-reviews">(${vet.reviews})</span>
            </div>
        </div>
        
        <div class="vet-sidebar-details">
            <div class="vet-sidebar-detail">
                <span class="vet-detail-label">Experience</span>
                <span class="vet-detail-value">${vet.experience}</span>
            </div>
            <div class="vet-sidebar-detail">
                <span class="vet-detail-label">Availability</span>
                <span class="vet-detail-value">${vet.availability}</span>
            </div>
        </div>
    `
}

// Handle form submission
function initBookingForm() {
  const form = document.getElementById("bookingForm")

  // Set minimum date to today
  const dateInput = document.getElementById("consultationDate")
  const today = new Date().toISOString().split("T")[0]
  dateInput.setAttribute("min", today)

  form.addEventListener("submit", (e) => {
    e.preventDefault()

    const formData = {
      consultationType: document.querySelector('input[name="consultationType"]:checked').value,
      date: document.getElementById("consultationDate").value,
      time: document.getElementById("consultationTime").value,
      petName: document.getElementById("petName").value,
      petType: document.getElementById("petType").value,
      petAge: document.getElementById("petAge").value,
      reason: document.getElementById("consultationReason").value,
      email: document.getElementById("contactEmail").value,
      phone: document.getElementById("contactPhone").value,
    }

    console.log("[v0] Booking submitted:", formData)

    // Show success message
    alert(
      `Consultation booked successfully!\n\nYou will receive a confirmation email at ${formData.email} with the meeting details.`,
    )

    // Redirect to vet page
    window.location.href = "vet.html"
  })
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  loadVetInfo()
  initBookingForm()
})
