// Vet data
const allVets = [
  {
    id: 1,
    name: "Dr. Emily Parker",
    specialty: "general",
    specialtyLabel: "General Practice",
    avatar: "/placeholder.svg?key=vet1",
    rating: 4.9,
    reviews: 156,
    experience: "12 years",
    availability: "Mon-Fri, 9AM-5PM",
    description: "Experienced veterinarian specializing in preventive care and general health for all pets.",
  },
  {
    id: 2,
    name: "Dr. James Wilson",
    specialty: "surgery",
    specialtyLabel: "Surgery",
    avatar: "/placeholder.svg?key=vet2",
    rating: 4.8,
    reviews: 98,
    experience: "15 years",
    availability: "Tue-Sat, 10AM-6PM",
    description: "Board-certified veterinary surgeon with expertise in orthopedic and soft tissue procedures.",
  },
  {
    id: 3,
    name: "Dr. Sarah Chen",
    specialty: "dental",
    specialtyLabel: "Dental Care",
    avatar: "/placeholder.svg?key=vet3",
    rating: 4.9,
    reviews: 134,
    experience: "10 years",
    availability: "Mon-Thu, 8AM-4PM",
    description: "Specialized in veterinary dentistry with focus on oral health and dental surgery.",
  },
  {
    id: 4,
    name: "Dr. Michael Brown",
    specialty: "emergency",
    specialtyLabel: "Emergency Care",
    avatar: "/placeholder.svg?key=vet4",
    rating: 4.7,
    reviews: 203,
    experience: "18 years",
    availability: "24/7 Emergency",
    description: "Emergency veterinarian with extensive experience in critical care and urgent treatments.",
  },
]

let filteredVets = [...allVets]

// Initialize vets page
function initVets() {
  const searchInput = document.getElementById("searchVets")
  const filterSpecialty = document.getElementById("filterSpecialty")

  const applyFilters = () => {
    const searchTerm = searchInput.value.toLowerCase()
    const selectedSpecialty = filterSpecialty.value

    filteredVets = allVets.filter((vet) => {
      // Search filter
      if (
        searchTerm &&
        !vet.name.toLowerCase().includes(searchTerm) &&
        !vet.specialtyLabel.toLowerCase().includes(searchTerm)
      ) {
        return false
      }

      // Specialty filter
      if (selectedSpecialty && vet.specialty !== selectedSpecialty) {
        return false
      }

      return true
    })

    renderVets()
  }

  searchInput.addEventListener("input", applyFilters)
  filterSpecialty.addEventListener("change", applyFilters)

  applyFilters()
}

// Render vets
function renderVets() {
  const grid = document.getElementById("vetsGrid")

  grid.innerHTML = filteredVets
    .map(
      (vet) => `
        <div class="vet-card">
            <div class="vet-header">
                <img src="${vet.avatar}" alt="${vet.name}" class="vet-avatar">
                <div class="vet-info">
                    <div class="vet-name">${vet.name}</div>
                    <div class="vet-specialty">${vet.specialtyLabel}</div>
                    <div class="vet-rating">
                        <span class="vet-stars">${"★".repeat(Math.floor(vet.rating))}${"☆".repeat(5 - Math.floor(vet.rating))}</span>
                        <span class="vet-reviews">(${vet.reviews} reviews)</span>
                    </div>
                </div>
            </div>
            
            <div class="vet-details">
                <div class="vet-detail-row">
                    <span class="vet-detail-label">Experience</span>
                    <span class="vet-detail-value">${vet.experience}</span>
                </div>
                <div class="vet-detail-row">
                    <span class="vet-detail-label">Availability</span>
                    <span class="vet-detail-value">${vet.availability}</span>
                </div>
            </div>
            
            <p class="vet-description">${vet.description}</p>
            
            <div class="vet-actions">
                <a href="vet-booking.html?id=${vet.id}" class="btn-primary">Book Consultation</a>
                <button class="btn-secondary" onclick="viewVetProfile(${vet.id})">View Profile</button>
            </div>
        </div>
    `,
    )
    .join("")
}

// View vet profile
function viewVetProfile(vetId) {
  alert("Vet profile page would be shown here")
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  initVets()
})
