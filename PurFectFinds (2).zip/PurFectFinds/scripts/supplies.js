// Product data
const allProducts = [
  {
    id: 1,
    name: "Premium Dog Food",
    category: "food",
    petType: "dogs",
    price: 49.99,
    image: "/placeholder.svg?key=dog-food",
    rating: 4.8,
    reviews: 234,
  },
  {
    id: 2,
    name: "Interactive Cat Toy",
    category: "toys",
    petType: "cats",
    price: 15.99,
    image: "/placeholder.svg?key=cat-toy",
    rating: 4.6,
    reviews: 156,
  },
  {
    id: 3,
    name: "Orthopedic Dog Bed",
    category: "accessories",
    petType: "dogs",
    price: 79.99,
    image: "/placeholder.svg?key=dog-bed",
    rating: 4.9,
    reviews: 312,
  },
  {
    id: 4,
    name: "Cat Scratching Post",
    category: "accessories",
    petType: "cats",
    price: 39.99,
    image: "/placeholder.svg?key=cat-scratch",
    rating: 4.7,
    reviews: 189,
  },
  {
    id: 5,
    name: "Pet Grooming Kit",
    category: "grooming",
    petType: "dogs",
    price: 34.99,
    image: "/placeholder.svg?key=grooming",
    rating: 4.5,
    reviews: 98,
  },
  {
    id: 6,
    name: "Automatic Pet Feeder",
    category: "accessories",
    petType: "dogs",
    price: 89.99,
    image: "/placeholder.svg?key=feeder",
    rating: 4.8,
    reviews: 267,
  },
  {
    id: 7,
    name: "Cat Litter Box",
    category: "accessories",
    petType: "cats",
    price: 45.99,
    image: "/placeholder.svg?key=litter",
    rating: 4.6,
    reviews: 143,
  },
  {
    id: 8,
    name: "Dog Training Treats",
    category: "food",
    petType: "dogs",
    price: 12.99,
    image: "/placeholder.svg?key=treats",
    rating: 4.9,
    reviews: 421,
  },
]

let filteredProducts = [...allProducts]
let cart = JSON.parse(localStorage.getItem("cart") || "[]")

// Initialize supplies page
function initSupplies() {
  const categoryCheckboxes = document.querySelectorAll('input[name="category"]')
  const petTypeCheckboxes = document.querySelectorAll('input[name="petType"]')
  const minPrice = document.getElementById("minPrice")
  const maxPrice = document.getElementById("maxPrice")
  const sortBy = document.getElementById("sortBy")
  const clearFilters = document.getElementById("clearFilters")

  const applyFilters = () => {
    filteredProducts = allProducts.filter((product) => {
      // Category filter
      const selectedCategories = Array.from(categoryCheckboxes)
        .filter((cb) => cb.checked)
        .map((cb) => cb.value)
      if (selectedCategories.length > 0 && !selectedCategories.includes(product.category)) {
        return false
      }

      // Pet type filter
      const selectedPetTypes = Array.from(petTypeCheckboxes)
        .filter((cb) => cb.checked)
        .map((cb) => cb.value)
      if (selectedPetTypes.length > 0 && !selectedPetTypes.includes(product.petType)) {
        return false
      }

      // Price filter
      const min = minPrice.value ? Number.parseFloat(minPrice.value) : 0
      const max = maxPrice.value ? Number.parseFloat(maxPrice.value) : Number.POSITIVE_INFINITY
      if (product.price < min || product.price > max) {
        return false
      }

      return true
    })

    // Apply sorting
    const sortValue = sortBy.value
    if (sortValue === "price-low") {
      filteredProducts.sort((a, b) => a.price - b.price)
    } else if (sortValue === "price-high") {
      filteredProducts.sort((a, b) => b.price - a.price)
    } else if (sortValue === "popular") {
      filteredProducts.sort((a, b) => b.reviews - a.reviews)
    } else {
      filteredProducts.sort((a, b) => b.id - a.id)
    }

    renderProducts()
  }

  categoryCheckboxes.forEach((cb) => cb.addEventListener("change", applyFilters))
  petTypeCheckboxes.forEach((cb) => cb.addEventListener("change", applyFilters))
  minPrice.addEventListener("input", applyFilters)
  maxPrice.addEventListener("input", applyFilters)
  sortBy.addEventListener("change", applyFilters)

  clearFilters.addEventListener("click", () => {
    categoryCheckboxes.forEach((cb) => (cb.checked = false))
    petTypeCheckboxes.forEach((cb) => (cb.checked = false))
    minPrice.value = ""
    maxPrice.value = ""
    sortBy.value = "newest"
    applyFilters()
  })

  applyFilters()
  updateCartUI()
}

function formatPrice(price) {
  return "₹" + price.toFixed(2)
}

// Render products
function renderProducts() {
  const grid = document.getElementById("productsGrid")
  const resultsCount = document.getElementById("resultsCount")

  resultsCount.textContent = `Showing ${filteredProducts.length} product${filteredProducts.length !== 1 ? "s" : ""}`

  grid.innerHTML = filteredProducts
    .map(
      (product) => `
        <div class="product-card">
            <img src="${product.image}" alt="${product.name}" class="product-image">
            <div class="product-content">
                <div class="product-name">${product.name}</div>
                <div class="product-category">${product.category.charAt(0).toUpperCase() + product.category.slice(1)}</div>
                <div class="product-price">${formatPrice(product.price)}</div>
                <div class="product-rating">
                    <span class="product-stars">${"★".repeat(Math.floor(product.rating))}${"☆".repeat(5 - Math.floor(product.rating))}</span>
                    <span class="product-reviews">(${product.reviews})</span>
                </div>
                <button class="btn-primary add-to-cart-btn" onclick="addToCart(${product.id})">Add to Cart</button>
            </div>
        </div>
    `,
    )
    .join("")
}

// Cart functions
function addToCart(productId) {
  const product = allProducts.find((p) => p.id === productId)
  const existingItem = cart.find((item) => item.id === productId)

  if (existingItem) {
    existingItem.quantity++
  } else {
    cart.push({ ...product, quantity: 1 })
  }

  localStorage.setItem("cart", JSON.stringify(cart))
  updateCartUI()
  showCartNotification()
}

function removeFromCart(productId) {
  cart = cart.filter((item) => item.id !== productId)
  localStorage.setItem("cart", JSON.stringify(cart))
  updateCartUI()
}

function updateQuantity(productId, change) {
  const item = cart.find((item) => item.id === productId)
  if (item) {
    item.quantity += change
    if (item.quantity <= 0) {
      removeFromCart(productId)
    } else {
      localStorage.setItem("cart", JSON.stringify(cart))
      updateCartUI()
    }
  }
}

function updateCartUI() {
  const cartCount = document.getElementById("cartCount")
  const cartItems = document.getElementById("cartItems")
  const cartTotal = document.getElementById("cartTotal")

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0)
  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)

  cartCount.textContent = totalItems

  if (cart.length === 0) {
    cartItems.innerHTML = '<div class="cart-empty">Your cart is empty</div>'
  } else {
    cartItems.innerHTML = cart
      .map(
        (item) => `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                <div class="cart-item-details">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-price">${formatPrice(item.price)}</div>
                    <div class="cart-item-quantity">
                        <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                        <span class="quantity-value">${item.quantity}</span>
                        <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
                    </div>
                </div>
                <button class="cart-item-remove" onclick="removeFromCart(${item.id})">✕</button>
            </div>
        `,
      )
      .join("")
  }

  cartTotal.textContent = formatPrice(totalPrice)
}

function toggleCart() {
  const cartSidebar = document.getElementById("cartSidebar")
  const cartOverlay = document.getElementById("cartOverlay")

  cartSidebar.classList.toggle("active")
  cartOverlay.classList.toggle("active")
}

function showCartNotification() {
  // Simple notification - could be enhanced with a toast component
  const notification = document.createElement("div")
  notification.textContent = "Added to cart!"
  notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background-color: var(--success);
        color: white;
        padding: 1rem 1.5rem;
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-lg);
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
    `
  document.body.appendChild(notification)

  setTimeout(() => {
    notification.remove()
  }, 2000)
}

function checkout() {
  if (cart.length === 0) {
    alert("Your cart is empty!")
    return
  }
  alert("Checkout functionality would be implemented here!")
}

// Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  initSupplies()
})
